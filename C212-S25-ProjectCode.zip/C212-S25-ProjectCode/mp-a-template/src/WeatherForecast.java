import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
// gson imports
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;



public class WeatherForecast {
    public static void main(String[] args) {
        String latitude = "39.168804";
        String longitude = "-86.536659";
        String unit = "fahrenheit";

        for (int i = 0; i < args.length - 1; i++) {
            switch (args[i]) {
                case "--latitude":
                    latitude = args[i + 1];
                    break;
                case "--longitude":
                    longitude = args[i+1];
                    break;
                case "--unit":
                    unit = args[i+1].equalsIgnoreCase("C") ? "celsius" : "fahrenheit";
                    break;
            }
        }
        String apiUrl = String.format(
                "https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&hourly=temperature_2m&temperature_unit=%s&timezone=EST",
                latitude, longitude, unit
        );
        try {
            // Making the GET request
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                throw new RuntimeException("HTTP GET request failed with response code: " + responseCode);
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Parsing the JSON
            JsonElement jsonElement = JsonParser.parseString(response.toString());
            JsonObject jsonObject = jsonElement.getAsJsonObject();
            JsonObject hourlyData = jsonObject.getAsJsonObject("hourly");

            JsonArray timeArray = hourlyData.getAsJsonArray("time");
            JsonArray tempArray = hourlyData.getAsJsonArray("temperature_2m");

            System.out.println("7-Day Forecast in " + (unit.equals("celsius") ? "Celsius" : "Fahrenheit") + ":");
            String currentDate = "";
            for (int i = 0; i < timeArray.size(); i += 3) {
                String timeStamp = timeArray.get(i).getAsString();
                String temp = tempArray.get(i).getAsString();

                String date = timeStamp.split("T")[0];

                if (!date.equals(currentDate)) {
                    System.out.println("\nForecast for " + date + ":");
                    currentDate = date;
                }

                System.out.printf("%s: %s %s%n", timeStamp.split("T")[1], temp, unit.equals("celsius") ? "°C" : "°F");
            }
        } catch (Exception e) {
            System.err.println("Error fetching weather data: " + e.getMessage());
        }
    }
}
