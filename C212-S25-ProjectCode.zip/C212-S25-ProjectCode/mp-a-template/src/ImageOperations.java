import java.awt.*;
import java.awt.image.BufferedImage;

class ImageOperations {

    /**
     * Removes the red channel from the given image
     *
     * @param img The original image
     * @return A new BI with the red channel removed.
     */
    static BufferedImage zeroRed(BufferedImage img) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage newImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = new Color(img.getRGB(x,y));

                Color newColor = new Color(0, color.getGreen(), color.getBlue());

                newImg.setRGB(x, y, newColor.getRGB());
            }
        }
        return newImg;
    }

    /**
     * Convert image to grayscale
     *
     * @param img original image
     * @return new BI converted to grayscale.
     */
    static BufferedImage grayscale(BufferedImage img) {
        int width = img.getWidth();
        int height = img.getHeight();

        BufferedImage newImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y ++) {
            for (int x = 0; x < width; x++) {
                Color color = new Color(img.getRGB(x,y));

                int gray = (int) (0.3 * color.getRed() + 0.59 * color.getGreen() + 0.11 * color.getBlue());

                Color newColor = new Color(gray, gray, gray);
                newImg.setRGB(x, y, newColor.getRGB());
            }
        }
        return newImg;
    }

    /**
     * invert color of img
     * @param img original image
     * @return new BI with inverted colors.
     */
    static BufferedImage invert(BufferedImage img) {
        int width = img.getWidth();
        int height = img.getHeight();

        BufferedImage newImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = new Color(img.getRGB(x,y));

                int red = 255 - color.getRed();
                int green = 255 - color.getGreen();
                int blue = 255 - color.getBlue();

                Color newColor = new Color(red, green, blue);
                newImg.setRGB(x, y, newColor.getRGB());
            }
        }
        return newImg;
    }

    /**
     * Mirrors image either horizontally or vertically
     *
     * @param img original image
     * @param dir direction of mirror
     * @return new BI with mirrored pixels.
     */
    static BufferedImage mirror(BufferedImage img, MirrorMenuItem.MirrorDirection dir) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage newImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        if (dir == MirrorMenuItem.MirrorDirection.VERTICAL) {
            // TODO mirror the image vertically.
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    newImg.setRGB(x, height - 1 - y, img.getRGB(x, y));
                }
            }
        } else {
            // TODO mirror the image horizontally.
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    newImg.setRGB(width - 1 - x, y, img.getRGB(x,y));
                }
            }
        }
        return newImg;
    }

    /**
     * Rotates given image 90 degrees in the specified direction.
     *
     * @param img original image
     * @param dir direction to rotate
     * @return new BI with rotated image.
     */
    static BufferedImage rotate(BufferedImage img, RotateMenuItem.RotateDirection dir) {
        // TODO instantiate newImg with the *correct* dimensions.
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage newImg = new BufferedImage(height, width, BufferedImage.TYPE_INT_RGB);

        if (dir == RotateMenuItem.RotateDirection.CLOCKWISE) {
            // TODO rotate the image clockwise.
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    newImg.setRGB(height - 1 - y, x, img.getRGB(x,y));
                }
            }
        } else {
            // TODO rotate the image counter-clockwise.
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    newImg.setRGB(y, width - 1 - x, img.getRGB(x,y));
                }
            }
        }
        return newImg;
    }

    /**
     * repeats given image horizontally or vertically
     *
     * @param img og image to repeat
     * @param n   number of times to repeat
     * @param dir direction to repeat in.
     * @return new BI containing the repeated pattern.
     */
    static BufferedImage repeat(BufferedImage img, int n, RepeatMenuItem.RepeatDirection dir) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage newImg = null;
        // newImg must be instantiated in both branches with the correct dimensions.
        if (dir == RepeatMenuItem.RepeatDirection.HORIZONTAL) {
            // TODO repeat the image horizontally.
            newImg = new BufferedImage(width * n, height, BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < n; i++) {
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        newImg.setRGB((i * width) + x, y, img.getRGB(x,y));
                    }
                }
            }
        } else {
            newImg = new BufferedImage(width, height * n, BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < n; i++) {
                for (int y = 0; y < height; y++) {
                    for (int x = 0; x < width; x++) {
                        newImg.setRGB(x, (i * height) + y, img.getRGB(x, y));
                    }
                }
            }
        }
        return newImg;
    }

    /**
     * Zooms in on the image. The zoom factor increases in multiplicatives of 10% and
     * decreases in multiplicatives of 10%.
     *
     * @param img        the original image to zoom in on. The image cannot be already zoomed in
     *                   or out because then the image will be distorted.
     * @param zoomFactor The factor to zoom in by.
     * @return the zoomed in image.
     */
    static BufferedImage zoom(BufferedImage img, double zoomFactor) {
        int newImageWidth = (int) (img.getWidth() * zoomFactor);
        int newImageHeight = (int) (img.getHeight() * zoomFactor);
        BufferedImage newImg = new BufferedImage(newImageWidth, newImageHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = newImg.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.drawImage(img, 0, 0, newImageWidth, newImageHeight, null);
        g2d.dispose();
        return newImg;
    }
}
